package jersey.model;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Club {

	private String name;
	private String city;
	private String fandom;
	private String stadium;
	
	public Club() {
		super();
	}
	
	public Club(String name, String city, String fandom, String stadium) {
		super();
		this.name = name;
		this.city = city;
		this.fandom = fandom;
		this.stadium = stadium;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getFandom() {
		return fandom;
	}

	public void setFandom(String fandom) {
		this.fandom = fandom;
	}

	public String getStadium() {
		return stadium;
	}

	public void setStadium(String stadium) {
		this.stadium = stadium;
	}
	
	
	
}
