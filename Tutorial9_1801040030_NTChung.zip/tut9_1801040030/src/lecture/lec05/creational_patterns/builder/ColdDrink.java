package lecture.lec05.creational_patterns.builder;

public abstract class ColdDrink implements Item {
	@Override
	public abstract float price();
}