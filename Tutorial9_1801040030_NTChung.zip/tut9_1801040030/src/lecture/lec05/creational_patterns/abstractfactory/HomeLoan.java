package lecture.lec05.creational_patterns.abstractfactory;

class HomeLoan extends Loan{  
    public void getInterestRate(double r){  
        rate=r;  
   }  
}//End of the HomeLoan class.  