package jersey.service;

import java.util.ArrayList;
import java.util.List;

import jersey.model.Club;

public class ClubService {
	public List<Club> getAllClubs() {
		Club s1 = new Club ("Arsenal", "London", "Gooners", "Emirates");
		Club s2 = new Club ("Manchester City", "Manchester", "Citizens", "Etihad");
		Club s3 = new Club ("Real Madrid", "Madrid", "Madridistas", "Bernabeu");
		Club s4 = new Club ("Barcelona", "Barcelona", "Cules", "Nou Camp");

		List<Club> list = new ArrayList<Club>();
		list.add(s1);
		list.add(s2);
		list.add(s3);
		list.add(s4);
		
		return list;
	}
}
