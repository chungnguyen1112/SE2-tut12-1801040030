package lecture.lec05.behavioral_patterns.interpreter;


public interface Pattern {
	
	
	public String conversion(String exp);

}
