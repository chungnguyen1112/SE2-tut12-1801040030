/* Create new database */
CREATE DATABASE USERDBS;
/* Use this database */
USE USERDBS;
/* Create new table */
CREATE TABLE USER (
ID INT NOT NULL AUTO_INCREMENT,
NAME VARCHAR(30) NOT NULL,
ADDRESS VARCHAR(50) NOT NULL,
MOBILE VARCHAR(10) NOT NULL,
PRIMARY KEY(ID));
/* Insert data to this table */
INSERT INTO USER (NAME, ADDRESS, MOBILE) VALUE ("Hoàng", "Hà Nội", "0912345678"), ("Minh", "Đà Nẵng", "0988888888"), ("Phương", "HCM", "0986868686");
/* Create new table */
CREATE TABLE COURSE (
COURSE_ID VARCHAR(15),
NAME VARCHAR(30),
PRIMARY KEY(COURSE_ID));
/* Insert data to this table */
INSERT INTO COURSE (COURSE_ID, NAME) VALUE ("2021SE2", "Sf Engineering"), ("2021SS2", "Special Subject");
/* Create new table */
CREATE TABLE FINAL_MARK (
ID VARCHAR(15),
NAME VARCHAR(30),
FINAL_MARK INT(5),
PRIMARY KEY(ID));
/* Insert data to this table */
INSERT INTO FINAL_MARK (ID, NAME, FINAL_MARK) VALUE ('1', 'Hoang', '9'), ('2', 'Minh', '7'), ('3', 'Phuong', '8');





