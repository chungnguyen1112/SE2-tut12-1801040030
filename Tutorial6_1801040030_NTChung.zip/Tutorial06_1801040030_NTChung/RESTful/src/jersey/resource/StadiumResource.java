package jersey.resource;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import jersey.model.Stadium;
import jersey.service.StadiumService;

@Path("/stadium")
public class StadiumResource {
	StadiumService stadiumService = new StadiumService();
	
	@GET
	@Produces(MediaType.APPLICATION_XML) 
	public List<Stadium> getStadium() {
		return stadiumService.getAllStadiums();
	}
}
