package tut7;

public class TestBag {
	public static void main(String[] args) {
		BagInterface<String> mobileBag = new ArrayBag();
		System.out.println("Initial bag size: " + mobileBag.getCurrentSize());
		System.out.println("Before adding objects: isEmpty() " + mobileBag.isEmpty());
		System.out.println("Adding some objects to the bag... ");
		mobileBag.add("Iphone");
		mobileBag.add("Samsung");
		
	}

}
