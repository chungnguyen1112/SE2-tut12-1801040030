package jersey.service;

import java.util.ArrayList;
import java.util.List;

import jersey.model.Footballer;

public class FootballerService {
	public List<Footballer> getAllFootballers() {
		Footballer s1 = new Footballer (1, "Leno", "GK", "German");
		Footballer s2 = new Footballer (2, "Bellerin", "RB", "Spanish");
		Footballer s3 = new Footballer (6, "Gabriel", "CB", "Brazilian");
		Footballer s4 = new Footballer (7, "Saka", "LW", "English");
		Footballer s5 = new Footballer (14, "Aubameyang", "ST", "Gabonese");
		Footballer s6 = new Footballer (18, "Partey", "CM", "Ghanaian");
		Footballer s7 = new Footballer (32, "Smith Rowe", "CAM", "English");
		Footballer s8 = new Footballer (34, "Xhaka", "CM", "Swiss");
		
		
		List<Footballer> list = new ArrayList<Footballer>();
		list.add(s1);
		list.add(s2);
		list.add(s3);
		list.add(s4);
		list.add(s5);
		list.add(s6);
		list.add(s7);
		list.add(s8);
		return list;
	}
}
