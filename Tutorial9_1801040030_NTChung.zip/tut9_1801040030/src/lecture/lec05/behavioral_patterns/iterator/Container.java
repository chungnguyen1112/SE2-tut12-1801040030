package lecture.lec05.behavioral_patterns.iterator;


public interface Container {

	public Iterator getIterator();
	
}
