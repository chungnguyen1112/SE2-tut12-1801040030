package lecture.lec05.behavioral_patterns.command;


public interface ActionListenerCommand {
	
	public void execute();

}
