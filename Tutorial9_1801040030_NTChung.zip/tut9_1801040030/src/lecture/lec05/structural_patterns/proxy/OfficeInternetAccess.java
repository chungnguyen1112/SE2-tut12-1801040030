package lecture.lec05.structural_patterns.proxy;


public interface OfficeInternetAccess {
	
	public void grantInternetAccess();

}
