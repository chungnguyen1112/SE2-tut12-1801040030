package lecture.lec05.creational_patterns.abstractfactory;

public interface Bank {
	String getBankName();
}
