package lecture.lec05.creational_patterns.abstractfactory;

class EducationLoan extends Loan{  
    public void getInterestRate(double r){  
      rate=r;  
}  
}//End of the EducationLoan class.  
