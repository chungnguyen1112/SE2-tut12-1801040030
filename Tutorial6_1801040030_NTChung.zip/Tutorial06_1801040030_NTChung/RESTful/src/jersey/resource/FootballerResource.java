package jersey.resource;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import jersey.model.Footballer;
import jersey.service.FootballerService;

@Path("/footballer")
public class FootballerResource {
	FootballerService footballerService = new FootballerService();
	
	@GET
	@Produces(MediaType.APPLICATION_XML) 
	public List<Footballer> getFootballer() {
		return footballerService.getAllFootballers();
	}
}
