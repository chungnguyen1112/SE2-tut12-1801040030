package servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/HelloServlet")
public class HelloServlet extends HttpServlet{ 
   protected void doGet (HttpServletRequest req, HttpServletResponse res) 
		   throws ServletException, IOException {
	   //Reading the user's input
	   String name = req.getParameter("name");
	   String pass = req.getParameter("pass");
	   //Setting the content type
	   res.setContentType("text/html");
	   //Getting the stream to write the data
	   PrintWriter pw = res.getWriter();
	   
	   if (name.equals("sontriplelift")) {
		   if (pass.equals("12345678")) {
			 //Writing html in the stream
			   pw.println(
					   "<html>\n" +
			             "<body>" + 
			             "<h2> Hello " + name + " !\n" + 
			             "</body>" +
			             "</html>"   
					   ); 
			   //Closing the stream
			   pw.close();
		   } else {
			   pw.println(
					   "<html>\n" +
			             "<body>" + 
			             "<h2> Wrong password!\n" + 
			             "</body>" +
			             "</html>"   
					   ); 
		   }
	   } else {
		   pw.println(
				   "<html>\n" +
		             "<body>" + 
		             "<h2> Invalid username!\n" + 
		             "</body>" +
		             "</html>"   
				   ); 
	   }
	  
   }
}



//package servlet;
//
//import java.io.IOException;
//import java.io.PrintWriter;
//
//import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//
//@WebServlet("/HelloServlet")
//public class HelloServlet extends HttpServlet{ 
//   protected void doGet (HttpServletRequest req, HttpServletResponse res) 
//		   throws ServletException, IOException {
//	   //Reading the user's input
//	   String name = req.getParameter("name");
//	   //Setting the content type
//	   res.setContentType("text/html");
//	   //Getting the stream to write the data
//	   PrintWriter pw = res.getWriter();
//	   //Writing html in the stream
//	   pw.println(
//			   "<html>\n" +
//	             "<body>" + 
//	             "<h2> Hello " + name + " !\n" + 
//	             "</body>" +
//	             "</html>"   
//			   ); 
//	   //Closing the stream
//	   pw.close();
//   }
//}



//package servlet;
//
//import java.io.IOException;
//import java.io.PrintWriter;
//
//import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
// 
//
//@WebServlet("/HelloServlet")
//public class HelloServlet extends HttpServlet {
//	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
//		   //Reading the user's input
//		   String acc = req.getParameter("acc");
//		   String pass = req.getParameter("pass");
//		   //Setting the content type
//		   res.setContentType("text/html");
//		   //Getting the stream to write the data
//		   PrintWriter pw = res.getWriter();
//		   //Writing html in the stream
//		   if (true) {
//			   pw.println(
//					   "<html>\n" +
//			             "<body>" + 
//			             "<h2> Hello " + validateAccount(acc, pass) + " !\n" + 
//			             "</body>" +
//			             "</html>"   
//					   ); 
//			   //Closing the stream
//			   pw.close();
//		   } else {
//			   pw.println(
//					   "<html>\n" +
//					             "<body>" + 
//					             "<h2> Enter Again!\n" + 
//					             "<center>"+
//								   "<form action=\"Hello\">"+
//							   		"<fieldset>"+
//							   			"Enter your username: <input type=\"text\" name=\"acc\" size=\"20\"> <br>"+
//							   			"<br> <input type=\"submit\" value=\"Submit\">"+
//							   		"</fieldset>"+
//							   		"<fieldset>"+
//							   			"Enter your password: <input type=\"text\" name=\"pass\" size=\"20\"> <br>"+
//							   			"<br> <input type=\"submit\" value=\"Submit\">"+
//							   		"</fieldset>"+
//							   	"</form>"+
//							   "</center>"+
//					             "</body>" +
//					    "</html>"
//					   
//
//					   ); 
//			   //Closing the stream
//			   pw.close();
//		   }
//
//	}
//	
//	public String validateAccount(String acc, String pass) {
//			if (acc == "v") {
//				return "True";
//			} else {
//				return "False: " + acc + " vs " + "viet";
//			}
//	}
//}	
	
