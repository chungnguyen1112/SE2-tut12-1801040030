package jersey.resource;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import jersey.model.Club;
import jersey.service.ClubService;

@Path("/club")
public class ClubResource {
	ClubService clubService = new ClubService();
	
	@GET
	@Produces(MediaType.APPLICATION_XML) 
	public List<Club> getClub() {
		return clubService.getAllClubs();
	}
}
