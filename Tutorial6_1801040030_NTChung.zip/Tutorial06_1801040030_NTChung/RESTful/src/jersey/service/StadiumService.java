package jersey.service;

import java.util.ArrayList;
import java.util.List;

import jersey.model.Stadium;

public class StadiumService {
	public List<Stadium> getAllStadiums() {
		Stadium s1 = new Stadium ("Emirates", 60704);
		Stadium s2 = new Stadium ("My Dinh", 40192);
	
		List<Stadium> list = new ArrayList<Stadium>();
		list.add(s1);
		list.add(s2);
		
		return list;
	}
}
