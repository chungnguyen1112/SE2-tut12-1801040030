
package model;

public class Final_mark {
	protected int id;
	protected String name;
	protected int final_mark;
	
	public Final_mark() {
	}
	
	public Final_mark(String name, int final_mark) {
		super();
		this.name = name;
		this.final_mark = final_mark;
	}

	public Final_mark(int id, String name, int final_mark) {
		super();
		this.id = id;
		this.name = name;
		this.final_mark = final_mark;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getFinal_mark() {
		return final_mark;
	}

	public void setFinal_mark(int final_mark) {
		this.final_mark = final_mark;
	}

}