package lecture.lec05.behavioral_patterns.iterator;


public interface Iterator {
	
	public boolean hasNext();
	
	public Object next();

}
