/* Create new database */
CREATE DATABASE userdb;
/* Use this database */
USE userdb;
/* Create new table */
CREATE TABLE user (
id INT NOT NULL AUTO_INCREMENT,
name VARCHAR(30) NOT NULL,
address VARCHAR(50) NOT NULL,
mobile VARCHAR(10) NOT NULL,
PRIMARY KEY(id));
/* Insert data to this table */
INSERT INTO user (name, address, mobile) VALUE ('Hoàng', 'Hà Nội', '0912345678'), ('Minh', 'Đà Nẵng', '0988888888'), ('Phương', 'HCM', '0986868686');