package lecture.lec05.behavioral_patterns.mediator;


public interface ApnaChatRoom {
	
	public void showMsg(String msg, Participant p);

}
