package lecture.lec05.structural_patterns.facade;


public interface MobileShop {
	
	
	public void modelNo();
	
	public void price();

}
