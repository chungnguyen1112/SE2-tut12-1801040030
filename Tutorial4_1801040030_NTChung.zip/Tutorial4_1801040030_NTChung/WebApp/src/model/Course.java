package model;


	/**
	 * This is a model class represents a User entity for the table User in database
	 */

public class Course {
		protected String course_id;
		protected String name;
		
		public Course() {
		}
		
		public Course(String course_id, String name) {
			super();
			this.course_id = course_id;
			this.name = name;
			
		}

		public String getCourse_id() {
			return course_id;
		}

		public void setCourse_id(String course_id) {
			this.course_id = course_id;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

}