package lecture.lec05.structural_patterns.adapter;



// this is the target interface.

public interface CreditCard 

{
	public void giveBankDetails();
	public String getCreditCard();
	
}
