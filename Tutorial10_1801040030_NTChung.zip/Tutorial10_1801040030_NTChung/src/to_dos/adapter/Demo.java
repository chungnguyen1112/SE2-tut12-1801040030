package to_dos.adapter;

public class Demo {

}
