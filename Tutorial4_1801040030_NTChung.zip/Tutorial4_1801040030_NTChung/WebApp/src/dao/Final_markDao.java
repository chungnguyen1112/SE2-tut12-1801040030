package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import connect.DBConnect;
import model.Final_mark;

/**
 * This is a DAO (DATA ACCESS OBJECT) class which provides 
 * CRUD (CREATE - READ - UPDATE - DELETE) database operations 
 * for the table user in the database
 */
public class Final_markDao {

	public Final_markDao() {
	}

	public List<Final_mark> selectAllFinal_marks() {

		List<Final_mark> final_marks = new ArrayList<>();
		// Step 1: Establishing a Connection
		Connection connection = DBConnect.getConnection();
		try {
			// Step 2:Create a statement using connection object
			String SELECT_ALL_Final_marks = "SELECT * FROM final_mark";
			PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_Final_marks);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();
			// Step 4: Process the ResultSet object
			while (rs.next()) {
				int id = rs.getInt("id");
				String name = rs.getString("name");
				int final_mark = rs.getInt("final_mark");
				final_marks.add(new Final_mark(id, name, final_mark));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return final_marks;
	}
}
