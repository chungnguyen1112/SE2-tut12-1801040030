package lecture.lec05.behavioral_patterns.strategy;


public interface Strategy {
	
	public float calculation(float a, float b);

}
