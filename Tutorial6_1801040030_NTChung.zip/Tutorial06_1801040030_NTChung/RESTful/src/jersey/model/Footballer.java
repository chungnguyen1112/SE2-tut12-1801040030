package jersey.model;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Footballer {
	private int number;
	private String name;
	private String position;
	private String nationality;

	public Footballer() {
		super();
	}

	public Footballer(int number, String name, String position, String nationality) {
		super();
		this.number = number;
		this.name = name;
		this.position = position;
		this.nationality = nationality;
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}
	
	

}	
